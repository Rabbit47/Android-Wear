package com.example.oven.timingnote;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.ThumbnailUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {

	private Context context;
	private Cursor cursor;
	private LinearLayout layout;
	private GridView listView;
	private int Ib=1;

	public MyAdapter(Context context, Cursor cursor) {
		this.context = context;
		this.cursor = cursor;
	}

	@Override
	public int getCount() {
		return cursor.getCount();
	}

	@Override
	public Object getItem(int position) {
		return cursor.getPosition();
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		LayoutInflater inflater = LayoutInflater.from(context);
		layout = (LinearLayout) inflater.inflate(R.layout.item,null);
		TextView contenttv = (TextView) layout.findViewById(R.id.contents);
		TextView titletv = (TextView) layout.findViewById(R.id.titles);
		TextView timetv = (TextView) layout.findViewById(R.id.datetime);
		cursor.moveToPosition(position);
		String content = cursor.getString(cursor.getColumnIndex("content"));
		String time = cursor.getString(cursor.getColumnIndex("time"));
		String title = cursor.getString(cursor.getColumnIndex("title"));
		contenttv.setText(content);
		timetv.setText(time);
		titletv.setText(title);
		final ImageButton imageButton=layout.findViewById(R.id.navigationalarm);
		imageButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(Ib==1){//Ib是定时开关判断条件可以替换。
					imageButton.setImageResource(R.drawable.ic_notification_item);
					Ib=0;
				}else {
					imageButton.setImageResource(R.drawable.ic_notification_item_off);
					Ib=1;
				}


			}
		});
		listView = (GridView) parent; //父控件实例化
		if (listView.isItemChecked(position)){//改变列表字体颜色
			contenttv.setTextColor(Color.RED);
			timetv.setTextColor(Color.RED);
			titletv.setTextColor(Color.RED);
		}else {
			contenttv.setTextColor(Color.GRAY);
			timetv.setTextColor(Color.GRAY);
			titletv.setTextColor(Color.GRAY);
		}
		return layout;
	}



}
