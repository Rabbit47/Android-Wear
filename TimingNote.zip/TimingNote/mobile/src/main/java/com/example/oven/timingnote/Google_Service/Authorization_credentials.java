package com.example.oven.timingnote.Google_Service;

import com.example.oven.timingnote.R;

public class Authorization_credentials {


    public static final String
            Authorization_Certificate="https://accounts.google.com/o/oauth2/v2/auth?\n" +
            " scope=https://www.googleapis.com/auth/calendar\n" +
            " response_type=code&\n" +
            " state=security_token%3D138r5719ru3e1%26url%3Dhttps://oauth2.example.com/token&\n" +
            " redirect_uri=com.example.oven:/oauth2redirect&\n" +
            " client_id="+ R.string.server_client_id;
}
