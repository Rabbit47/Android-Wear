package com.example.oven.timingnote;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.net.ParseException;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.oven.timingnote.DB.NoteDB;

import java.util.Date;

import static com.example.oven.timingnote.DB.NoteDB.ID;

public class Edit extends AppCompatActivity {
    private  String Hour;
    private  String Minute;
    private  String Day;
    private  String Month;
    boolean isNeedChangeSearchIcon = false;
    private int page = 0;
    private PendingIntent sender;
    public EditText title;
    public EditText content;
    public TextView datetime;
    private Cursor cursor;
    private NoteDB noteDB;
    private SQLiteDatabase dbReader;
    private SQLiteDatabase dbWriter;
    public static int flag = 0;
    private Calendar calendar;
    private AlarmManager alarmManager;

    public BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_change:
                    if (flag == 0) {
                        // 第一次单击触发的事件
                        contentLayout(content);//切换到内容
                        flag = 1;
                    } else {
                        // 第二次单击button.text改变触发的事件

                        titleLayout(title);//切换到标题
                        flag = 0;
                    }

                    return true;
                case R.id.navigation_Timing:

                        Timing();
                    return true;
                case R.id.navigation_save:
                    if(getIntent().getStringExtra(NoteDB.ID)!=null){
                        saveDB();
                    }else {
                        addDB();

                    }

                    finish();
                    return true;
            }
            return false;
        }

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {//编辑页面主程序
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        Refresh_toolbar();
        datetime=(TextView)findViewById(R.id.datetime);
        content= (EditText) findViewById(R.id.content);
        title= (EditText) findViewById(R.id.title);
        if(getIntent().getStringExtra(NoteDB.ID)!=null){

            editText();
        }else {
            addText();;
        }


        calendar = Calendar.getInstance();
        noteDB=new NoteDB(this);
        dbWriter= noteDB.getWritableDatabase();
        dbReader=noteDB.getReadableDatabase();
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }//编辑页面主程序
    public void  addText(){
        datetime.setText(getTime());
    }
    public void  editText(){
        content.setText(getIntent().getStringExtra(NoteDB.CONTENT));
        datetime.setText(getIntent().getStringExtra(NoteDB.TIME));
        title.setText(getIntent().getStringExtra(NoteDB.TITLE));
    }
    public void contentLayout(View view){//切换到内容
        if(view.isFocused()){//已获得焦点
            view.clearFocus();//失去焦点
        }else{
            view.requestFocus();//获得焦点
        }


    }//切换到内容
    public void titleLayout(View view){//切换到标题
        if(view.isFocused()){//已获得焦点
            view.clearFocus();//失去焦点
        }else{
            view.requestFocus();//获得焦点
        }


    }//切换到标题
    public void addDB() {//写入数据库表单
        ContentValues cv = new ContentValues();
        cv.put(NoteDB.TITLE, title.getText().toString());
        cv.put(NoteDB.CONTENT, content.getText().toString());
        cv.put(NoteDB.TIME, datetime.getText().toString());;
        dbWriter.insert(NoteDB.TABLE_NAME, null, cv);

    }//写入数据库表单
    public void saveDB() {//覆盖数据库表单
        ContentValues cv = new ContentValues();
        cv.put(NoteDB.TITLE, title.getText().toString());
        cv.put(NoteDB.CONTENT, content.getText().toString());
        cv.put(NoteDB.TIME, datetime.getText().toString());
        dbWriter.update("notes",cv,"_id=?",new String[]{getIntent().getStringExtra(NoteDB.ID)});

    }//覆盖数据库表单
    public String getTime() {//获取系统时间
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date curDate = new Date();
        String str = format.format(curDate);
        return str;
    }//获取系统时间
    public Calendar getSaveTime() throws java.text.ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date date = format.parse(datetime.getText().toString());
        long lg=date.getTime();
        Date dt=new Date(lg);
        System.out.println(lg);
        calendar.setTimeInMillis(lg);
        calendar.set(Calendar.SECOND,0);
        calendar.set(Calendar.MILLISECOND,0);
        System.out.println(calendar);
        return calendar;
    }//转换时间类型转换目前作废

    public void Timing(){
        DateTimePicker dateTimePicker = new DateTimePicker(Edit.this);
        dateTimePicker.setDateTimePickerListener(new DateTimePicker.IDateTimePickerListener() {
            @Override
            public void onClear() {
                Log.d("Date Time Picker:", "clear");
                datetime.setText("");
            }

            @Override
            public void onOK(int year, int month, int day, int hour, int minute) {
                Log.d("Date Time Picker:", year + "-" + month + "-" + day + " " + hour + ":" + minute);
                if(month<10&&day<10){
                    Month=String.format("%02d",month);
                    Day=String.format("%02d",day);
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(hour).append(":").append(minute));
                    }
                }else if(month<10&&day>=10){
                    Month=String.format("%02d",month);
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(hour).append(":").append(minute));
                    }
                }else if(day<10&&month>=10){
                    Day=String.format("%02d",hour);
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(hour).append(":").append(minute));
                    }
                }else{
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(hour).append(":").append(minute));
                    }
                }

            }
        });
        dateTimePicker.show();
    }//TimingDialog时间设定器
    public void Save_calendar(){

    }//更新日历事件
    public void Add_calendar(){

    }//添加事件
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        if (isNeedChangeSearchIcon) {
            MenuItem search = menu.findItem(R.id.alarm);
            search.setIcon(R.drawable.ic_notification_off);
        }
        return true;
    }//右侧菜单初始化


    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.alarm) {
            if (page == 0) {

                if (!isNeedChangeSearchIcon) {
                    Refresh_toolbar();
                    isNeedChangeSearchIcon = true;
                }
                page = 1;
            } else if (page == 1) {

                if (isNeedChangeSearchIcon) {
                    Refresh_toolbar();
                    isNeedChangeSearchIcon = false;
                }
                page = 0;
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }//右侧菜单点击事件
    public void Refresh_toolbar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarEdit);
        setSupportActionBar(toolbar);
    }//刷新右侧菜单
    //右侧菜单是决定是否定时，page相当于定时条件可替换
}
