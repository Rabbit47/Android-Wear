package com.example.oven.timingnote;

import android.accounts.AccountManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import com.example.oven.timingnote.DB.NoteDB;
import static com.example.oven.timingnote.DB.NoteDB.ID;
import static com.example.oven.timingnote.Google_Service.Authorization_credentials.Authorization_Certificate;

import java.util.HashSet;

public class MainActivity extends AppCompatActivity {
    boolean isNeedChangeSearchIcon = false;
    private GridView gridView;
    private NoteDB noteDB;
    private SQLiteDatabase dbReader;
    private SQLiteDatabase dbdelete;
    private SQLiteDatabase dbWriter;
    private Cursor cursor;
    private MyAdapter adapter;
    private Intent i;
    private int page = 0;
    private HashSet<Integer> hashSet;

    public void hashDelete() {
        if (hashSet.isEmpty()) {
            Toast.makeText(this, R.string.No_selection_item, Toast.LENGTH_SHORT).show();
        } else {
            Object[] obj = hashSet.toArray();
            int temp[] = new int[obj.length];
            for (int i = 0; i < obj.length; i++) {
                temp[i] = (int) obj[i];//将Object对象数组转为整型数组（强制向下转型）循环遍历Item的position逐条删除
                cursor.moveToPosition(temp[i]);
                int intemID = cursor.getInt(cursor.getColumnIndex("_id"));
                dbWriter.delete("notes", "_id=?", new String[]{intemID + ""});
            }
            selectDB();
            hashSet.clear();
        }

    }//多选删除方法

    public void home() {
        setTitle(R.string.app_name);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        noteDB = new NoteDB(this);
        dbWriter = noteDB.getWritableDatabase();
        dbReader = noteDB.getReadableDatabase();
        gridView = (GridView) findViewById(R.id.gv);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {//查看跳转
                Details(position,id);
            }
        });
        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, final long id) {//长按跳出问讯Dialog
                new AlertDialog.Builder(MainActivity.this).setTitle(R.string.title_edit).setNegativeButton(R.string.cancel, null).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        editDate(position, id);//编辑跳转
                    }
                }).show();

                return true;
            }
        });
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                i = new Intent(MainActivity.this, Edit.class);
                i.putExtra("fab", "fab");
                startActivity(i);
            }
        });

    }//主页模组

    public void delete_mode() {
        setTitle(R.string.title_delete);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        hashSet = new HashSet<Integer>();
        noteDB = new NoteDB(this);
        dbWriter = noteDB.getWritableDatabase();
        dbReader = noteDB.getReadableDatabase();
        gridView = (GridView) findViewById(R.id.gv);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                adapter.notifyDataSetChanged();//通知Item更新控件
                if (gridView.isItemChecked(position)) {
                    hashSet.add(position);//hash获取item的position
                    System.out.println(position);
                } else {
                    hashSet.remove(position);//hash释放item的position

                }

            }
        });
        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                new AlertDialog.Builder(MainActivity.this).setTitle(R.string.title_delete).setNegativeButton(R.string.cancel, null).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        cursor.moveToPosition(position);
                        int intemID = cursor.getInt(cursor.getColumnIndex("_id"));
                        dbWriter.delete("notes", "_id=?", new String[]{intemID + ""});
                        selectDB();
                    }
                }).show();

                return true;
            }
        });
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setImageResource(android.R.drawable.ic_menu_delete);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hashDelete();
            }
        });
        fab.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setTitle(R.string.title_deleteS).setNegativeButton(R.string.cancel, null).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dbdelete = noteDB.getWritableDatabase();
                        deleteTable(dbdelete);
                    }
                }).show();
                ;
                return false;
            }
        });

    }//删除模组

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        home();

    }//程序初始化


    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        if (isNeedChangeSearchIcon) {
            MenuItem search = menu.findItem(R.id.Delete_mode);
            search.setIcon(android.R.drawable.ic_menu_sort_by_size);
        }
        return true;
    }//右侧菜单初始化


    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.Refresh) {
            new AlertDialog.Builder(MainActivity.this).setTitle(R.string.Refresh).setNegativeButton(R.string.cancel, null).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    selectDB();
                }
            }).show();

            return true;
        } else if (id == R.id.Delete_mode) {
            setContentView(R.layout.activity_main);
            if (page == 0) {
                delete_mode();
                selectDB();
                if (!isNeedChangeSearchIcon) {

                    isNeedChangeSearchIcon = true;
                }
                page = 1;
            } else if (page == 1) {
                home();
                selectDB();
                if (isNeedChangeSearchIcon) {

                    isNeedChangeSearchIcon = false;
                }
                page = 0;
            }
        }

        return super.onOptionsItemSelected(item);
    }//右侧菜单点击事件

    public void selectDB() {
        cursor = dbReader.query(NoteDB.TABLE_NAME, null, null, null, null,
                null, null);
        adapter = new MyAdapter(this, cursor);
        gridView.setAdapter(adapter);
    }//更新列表方法

    public void select_Calendar() {//刷新日历事件列表

    }//读取刷新日历事件列表
    protected void onResume() {
        super.onResume();
        selectDB();
    }
    public void deleteTable(SQLiteDatabase db){
        db.execSQL("delete from notes");
        db.execSQL("delete from sqlite_sequence where name='notes'");
        selectDB();
    }//清空数据库
    private void editDate(int position, long id) {
        cursor.moveToPosition(position);
        Intent i = new Intent( MainActivity.this, Edit.class);
        i.putExtra("position",position+"");
        i.putExtra("id",id+"");
        i.putExtra(NoteDB.ID,String.valueOf(cursor.getInt(cursor.getColumnIndex(ID))));
        i.putExtra(NoteDB.CONTENT, cursor.getString(cursor
                .getColumnIndex(NoteDB.CONTENT)));
        i.putExtra(NoteDB.TIME,
                cursor.getString(cursor.getColumnIndex(NoteDB.TIME)));
        i.putExtra(NoteDB.TITLE,
                cursor.getString(cursor.getColumnIndex(NoteDB.TITLE)));
        startActivity(i);
    }//编辑跳转数据
    private void Details(int position, long id){
        cursor.moveToPosition(position);
        Intent i = new Intent(MainActivity.this, Details.class);
        i.putExtra("position", position + "");
        i.putExtra("id", id + "");
        i.putExtra(NoteDB.ID,
                cursor.getInt(cursor.getColumnIndex(ID)));
        i.putExtra(NoteDB.CONTENT, cursor.getString(cursor
                .getColumnIndex(NoteDB.CONTENT)));
        i.putExtra(NoteDB.TIME,
                cursor.getString(cursor.getColumnIndex(NoteDB.TIME)));
        i.putExtra(NoteDB.TITLE,
                cursor.getString(cursor.getColumnIndex(NoteDB.TITLE)));
        startActivity(i);
    }//查看跳转数据
    private void Details_calendar(int position, long id){
        cursor.moveToPosition(position);
        Intent i = new Intent(MainActivity.this, Details.class);
        i.putExtra("position", position + "");
        i.putExtra("id", id + "");
        i.putExtra(NoteDB.ID,
                cursor.getInt(cursor.getColumnIndex(ID)));
        i.putExtra(NoteDB.CONTENT, cursor.getString(cursor
                .getColumnIndex(NoteDB.CONTENT)));
        i.putExtra(NoteDB.TIME,
                cursor.getString(cursor.getColumnIndex(NoteDB.TIME)));
        i.putExtra(NoteDB.TITLE,
                cursor.getString(cursor.getColumnIndex(NoteDB.TITLE)));
        startActivity(i);
    }//日历查看跳转数据
    private void Edit_calendar(int position, long id) {
        cursor.moveToPosition(position);
        Intent i = new Intent( MainActivity.this, Edit.class);
        i.putExtra("position",position+"");
        i.putExtra("id",id+"");
        i.putExtra(NoteDB.ID,String.valueOf(cursor.getInt(cursor.getColumnIndex(ID))));
        i.putExtra(NoteDB.CONTENT, cursor.getString(cursor
                .getColumnIndex(NoteDB.CONTENT)));
        i.putExtra(NoteDB.TIME,
                cursor.getString(cursor.getColumnIndex(NoteDB.TIME)));
        i.putExtra(NoteDB.TITLE,
                cursor.getString(cursor.getColumnIndex(NoteDB.TITLE)));
        startActivity(i);
    }//日历编辑跳转数据
    public void Clear_calendar(SQLiteDatabase db){
        db.execSQL("delete from notes");
        db.execSQL("delete from sqlite_sequence where name='notes'");
        selectDB();
    }//清空事件


}