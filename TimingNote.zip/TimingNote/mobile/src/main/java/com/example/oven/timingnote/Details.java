package com.example.oven.timingnote;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import com.example.oven.timingnote.DB.NoteDB;

import static com.example.oven.timingnote.DB.NoteDB.ID;

public class Details extends AppCompatActivity {
    private TextView datatime;
    private EditText title;
    private EditText content;
    private NoteDB noteDB;
    private SQLiteDatabase dbWriter;
    private SQLiteDatabase dbReader;
    private Cursor cursor;
    boolean isNeedChangeSearchIcon = false;
    private int page = 0;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_revert:
                    finish();
                    return true;
                case R.id.navigation_delete:
                    deleteDate();
                    finish();
                    return true;
                case R.id.navigation_edit:
                    Intent i = getIntent();
                    String p=i.getStringExtra("position");
                    String ID=i.getStringExtra("id");
                    int position=Integer.parseInt(p);
                    long id= Long.parseLong(ID);
                    editDate(position,id);
                    finish();
                    return true;
            }
            return false;
        }

    };


    private void editDate(int position, long id) {
        cursor = dbReader.query(NoteDB.TABLE_NAME, null, null, null, null,
                null, null);
        cursor.moveToPosition(position);
        Intent i = new Intent(Details.this, Edit.class);
        i.putExtra("position",position+"");
        i.putExtra("id",id+"");
        i.putExtra(NoteDB.ID,String.valueOf(cursor.getInt(cursor.getColumnIndex(ID))));
        i.putExtra(NoteDB.CONTENT, cursor.getString(cursor
                .getColumnIndex(NoteDB.CONTENT)));
        i.putExtra(NoteDB.TIME,
                cursor.getString(cursor.getColumnIndex(NoteDB.TIME)));
        i.putExtra(NoteDB.TITLE,
                cursor.getString(cursor.getColumnIndex(NoteDB.TITLE)));
        startActivity(i);
        dbReader.close();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Refresh_toolbar();
        title= (EditText) findViewById(R.id.titleT);
        content= (EditText) findViewById(R.id.contentT);
        datatime= (TextView) findViewById(R.id.datetimeT);
        noteDB = new NoteDB(this);
        dbReader = noteDB.getReadableDatabase();
        dbWriter = noteDB.getWritableDatabase();
        content.setText(getIntent().getStringExtra(NoteDB.CONTENT));
        content.setKeyListener(null);
        datatime.setText(getIntent().getStringExtra(NoteDB.TIME));
        title.setText(getIntent().getStringExtra(NoteDB.TITLE));
        title.setKeyListener(null);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }
    public void deleteDate() {
        dbWriter.delete(NoteDB.TABLE_NAME,
                "_id=" + getIntent().getIntExtra(NoteDB.ID, 0), null);
        dbWriter.close();
    }//删除内容
    public void delete_calendar() {
        dbWriter.delete(NoteDB.TABLE_NAME,
                "_id=" + getIntent().getIntExtra(NoteDB.ID, 0), null);
        dbWriter.close();
    }//删除事件
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        if (isNeedChangeSearchIcon) {
            MenuItem search = menu.findItem(R.id.alarm);
            search.setIcon(R.drawable.ic_notification_off);
        }
        return true;
    }//右侧菜单初始化


    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.alarm) {
            if (page == 0) {

                if (!isNeedChangeSearchIcon) {
                    Refresh_toolbar();
                    isNeedChangeSearchIcon = true;
                }
                page = 1;
            } else if (page == 1) {

                if (isNeedChangeSearchIcon) {
                    Refresh_toolbar();
                    isNeedChangeSearchIcon = false;
                }
                page = 0;
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }//右侧菜单点击事件
    public void Refresh_toolbar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarDetails);
        setSupportActionBar(toolbar);
    }//刷新右侧菜单
//右侧菜单是决定是否定时，page相当于定时判断条件可以替换
}
