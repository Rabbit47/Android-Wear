package com.example.oven.timingnote;

class OnTokenAcquired {
}
