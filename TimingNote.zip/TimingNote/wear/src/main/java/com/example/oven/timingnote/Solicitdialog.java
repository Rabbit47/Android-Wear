package com.example.oven.timingnote;
//自定义选择通知控件
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

public class Solicitdialog extends DialogFragment implements View.OnClickListener{
    TextView solicit;
    ImageButton yes;
    ImageButton no;
    String str;
    private static Solicitdialog solicitdialog;
    public static Solicitdialog newInstance(String Solicit) {
        Solicitdialog shareDialogFragment = new Solicitdialog();
        Bundle bundle = new Bundle();
        bundle.putString("title",Solicit);
        shareDialogFragment.setArguments(bundle);
        return shareDialogFragment;
    }

    public static Solicitdialog newInstance() {
        if (solicitdialog == null) {
            Solicitdialog shareDialogFragment = new Solicitdialog();
        }
        return solicitdialog;
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.solicit, container, false);
        solicit= (TextView) view.findViewById(R.id.solicit);
        yes=view.findViewById(R.id.yes);
        no=view.findViewById(R.id.no);

       yes.setOnClickListener(this);
        no.setOnClickListener(this);
        solicit.setText(str+"?");
        return view;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        str= bundle.getString("flag");
        setCancelable(true);

    }
    public Dialog onCreateDialog(Bundle savedInstanceState) {


        Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.solicit);//绑定布局
        dialog.setCanceledOnTouchOutside(true);

        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(wlp);

        return dialog;
    }
    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.yes:
                        if (str==getString(R.string.menu_save)){
                            shareClickListener.Save();
                        }else if (str==getString(R.string.menu_delete)){
                            shareClickListener.Delete();
                        }else if (str==getString(R.string.clear)){
                            shareClickListener.Clear();
                        }
                break;
            case R.id.no:
                dismiss();
                break;

        }
    }
    private OnShareClickListener shareClickListener;

    public interface OnShareClickListener {//设置接口
        void Save();

        void Clear();

        void Delete();
    }

    public void setOnShareClickListener(OnShareClickListener shareClickListener) {
        this.shareClickListener = shareClickListener;
    }

    @Override
    public void show(FragmentManager manager, String tag) {

        super.show(manager, tag);
    }
}
