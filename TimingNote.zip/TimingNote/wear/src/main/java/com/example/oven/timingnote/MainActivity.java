/*
Copyright 2017 The Android Open Source Project

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */
package com.example.oven.timingnote;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.wearable.activity.WearableActivity;
import android.support.wearable.view.drawer.WearableActionDrawer;
import android.support.wearable.view.drawer.WearableNavigationDrawer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.oven.timingnote.SectionFragment.Section;

import java.util.List;

public class MainActivity extends WearableActivity {
    private  String Hour;
    private  String Minute;
    private  String Day;
    private  String Month;
    private TextView title;
    private TextView content;

    private String solicit;
    private SectionFragment.Section selectedSection;
    private int i=2,s=0;
    public TextView datetime;
    private Menu menu;
    private static Section DEFAULT_SECTION = Section.Home;
    private NoteDB noteDB;
    private SQLiteDatabase dbWriter;
    private WearableNavigationDrawer mWearableNavigationDrawer;
    private WearableActionDrawer mWearableActionDrawer;
    private static final int SPEECH_REQUEST_CODE = 0;
    private String spokenText;
    private Solicitdialog solicitdialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       mainlayout();

    }//初始化



    private void mainlayout() {
        noteDB=new NoteDB(this);
        dbWriter= noteDB.getWritableDatabase();
        mWearableNavigationDrawer =
                (WearableNavigationDrawer) findViewById(R.id.top_navigation_drawer);
        mWearableNavigationDrawer.setAdapter(new NavigationAdapter(this));
        final SectionFragment sunSection = SectionFragment.getSection(DEFAULT_SECTION);
        getFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, sunSection)
                .commit();

        mWearableActionDrawer = (WearableActionDrawer) findViewById(R.id.bottom_action_drawer);
        menu = mWearableActionDrawer.getMenu();
        mWearableActionDrawer.setOnMenuItemClickListener(
                new WearableActionDrawer.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {//按键菜单
                        mWearableActionDrawer.closeDrawer();
                        switch (menuItem.getItemId()) {
                            case R.id.menu_title:
                                Google_Voice();
                                i=0;
                                return true;
                            case R.id.menu_content:
                                Google_Voice();
                                i=1;
                                return true;
                            case R.id.menu_timing:
                                if (i==1||i==0){
                                    Timing();
                                }else{
                                    Toast.makeText(
                                            MainActivity.this,
                                            R.string.Please_enter_the_content_or_title_before_timing,
                                            Toast.LENGTH_SHORT)
                                            .show();
                                }

                                return true;
                            case R.id.menu_save:
                                if(i==2){
                                    Edit_Tost();
                                }else {
                                    solicit=getString(R.string.menu_save);
                                    solicit(solicit);

                                }


                                return true;
                            case R.id.menu_delete:
                                solicit=getString(R.string.menu_delete);
                                solicit(solicit);
                                return true;
                            case R.id.menu_clear:
                                solicit=getString(R.string.clear);
                                solicit(solicit);
                                return true;
                            case R.id.menu_sync:

                                return true;
                        }
                        return false;
                    }
                });


    }//初始化方法

    private void Timing() {
        DateTimePicker dateTimePicker = new DateTimePicker(MainActivity.this);
        dateTimePicker.setDateTimePickerListener(new DateTimePicker.IDateTimePickerListener() {
            @Override
            public void onClear() {
                Log.d("Date Time Picker:", "clear");
                datetime.setText("");
            }

            @Override
            public void onOK(int year, int month, int day, int hour, int minute) {
                Log.d("Date Time Picker:", year + "-" + month + "-" + day + " " + hour + ":" + minute);
                if(month<10&&day<10){
                    Month=String.format("%02d",month);
                    Day=String.format("%02d",day);
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(Day).append(" ").append(hour).append(":").append(minute));
                    }
                }else if(month<10&&day>=10){
                    Month=String.format("%02d",month);
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(Month).append("-").append(day).append(" ").append(hour).append(":").append(minute));
                    }
                }else if(day<10&&month>=10){
                    Day=String.format("%02d",hour);
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(Day).append(" ").append(hour).append(":").append(minute));
                    }
                }else{
                    if(hour<10&&minute<10){
                        Hour=String.format("%02d",hour);
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(Hour).append(":").append(Minute));
                    }else if(hour<10&&minute>=10){
                        Hour=String.format("%02d",hour);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(Hour).append(":").append(minute));
                    }else if(minute<10&&hour>=10){
                        Minute=String.format("%02d",minute);
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(hour).append(":").append(Minute));
                    }else{
                        datetime.setText(new StringBuffer().append(year).append("-").append(month).append("-").append(day).append(" ").append(hour).append(":").append(minute));
                    }
                }

            }
        });
        dateTimePicker.show();
    }//日期时间选择器

    @Override
    protected void onStart() {
        super.onStart();
        View view = this.findViewById(R.id.fragment_container);
        title=view.findViewById(R.id.title);
        content=view.findViewById(R.id.content);
        datetime=view.findViewById(R.id.datetime);

        if(i==0){
            title.setText(spokenText);
        }else if(i==1){
            content.setText(spokenText);
        }else {

        }


        Toast.makeText(
                MainActivity.this,
                R.string.The_system_is_loaded,
                Toast.LENGTH_SHORT)
                .show();

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private final class NavigationAdapter
            extends WearableNavigationDrawer.WearableNavigationDrawerAdapter {

        private final Context mContext;
        private Section mCurrentSection = DEFAULT_SECTION;

        NavigationAdapter(final Context context) {
            mContext = context;
        }

        @Override
        public String getItemText(int index) {
            return mContext.getString(SectionFragment.Section.values()[index].titleRes);
        }

        @Override
        public Drawable getItemDrawable(int index) {
            return mContext.getDrawable(SectionFragment.Section.values()[index].drawableRes);
        }

        @Override
        public void onItemSelected(int index) {
             selectedSection = SectionFragment.Section.values()[index];

            // Only replace the fragment if the section is changing.
            if (selectedSection == mCurrentSection) {
                return;
            }
            mCurrentSection = selectedSection;

            final SectionFragment sectionFragment = SectionFragment.getSection(selectedSection);
            getFragmentManager()
                    .beginTransaction()
                    .replace(R.                  id.fragment_container, sectionFragment)
                    .commit();

            // No actions are available for the settings specific fragment, so the drawer
            // is locked closed. For all other SelectionFragments, it is unlocked.
            if (selectedSection == SectionFragment.Section.Home) {
                mWearableActionDrawer.unlockDrawer();
                mWearableActionDrawer.getMenu().clear();
                getMenuInflater().inflate(R.menu.home_menu,menu);
                mWearableActionDrawer.setVisibility(View.VISIBLE);
            } else if(selectedSection==SectionFragment.Section.Delete){
                mWearableActionDrawer.unlockDrawer();
                mWearableActionDrawer.getMenu().clear();
                getMenuInflater().inflate(R.menu.cleared,menu);
                mWearableActionDrawer.setVisibility(View.VISIBLE);
                Toast.makeText(
                        MainActivity.this,
                        R.string.Long_press_to_delete,
                        Toast.LENGTH_SHORT)
                        .show();
            }else {
                mWearableActionDrawer.unlockDrawer();
                mWearableActionDrawer.getMenu().clear();
                getMenuInflater().inflate(R.menu.action_drawer_menu,menu);
                mWearableActionDrawer.setVisibility(View.VISIBLE);
                Edit_Tost();
            }


        }

        @Override
        public int getCount() {
            return SectionFragment.Section.values().length;
        }
    }//抽屉
    public void Google_Voice(){
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
// Start the activity, the intent will be populated with the speech text
        startActivityForResult(intent, SPEECH_REQUEST_CODE);
    }//谷歌语音入口

    // This callback is invoked when the Speech Recognizer returns.
// This is where you process the intent and extract the speech text from the intent.
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
            List<String> results = data.getStringArrayListExtra(
                    RecognizerIntent.EXTRA_RESULTS);
             spokenText = results.get(0);
            // Do something with spokenText
        }
        super.onActivityResult(requestCode, resultCode, data);
    }//谷歌语音出口
    public void addDB() {//写入数据库表单
        ContentValues cv = new ContentValues();
        cv.put(NoteDB.TITLE, title.getText().toString());
        cv.put(NoteDB.CONTENT, content.getText().toString());
        cv.put(NoteDB.TIME, datetime.getText().toString());
        dbWriter.insert(NoteDB.TABLE_NAME, null, cv);
    }//写入数据库
    public void Edit_Tost(){
        Toast.makeText(
                MainActivity.this,
                R.string.Please_enter_your_plan_first,
                Toast.LENGTH_SHORT)
                .show();
    }
    public void am(){
        Intent intent = new Intent();
        intent.putExtra("Clear","clear");
        intent.setAction("Clear");
        BroadCastManager.getInstance().sendBroadCast(this, intent);
    }//AM广播发射
    public void fm(){
        Intent intent = new Intent();
        intent.putExtra("delete","Delete");
        intent.setAction("Deletes");
        BroadCastManager.getInstance().sendBroadCast(this, intent);
    }//FM广播发射
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
    public void solicit(String solicit){
        solicitdialog= new Solicitdialog();
        Bundle bundle = new Bundle();
        bundle.putString("flag",solicit);
        solicitdialog.setArguments(bundle);
        solicitdialog.show(getFragmentManager(),null);
        solicitdialog.setOnShareClickListener(new Solicitdialog.OnShareClickListener() {
            @Override
            public void Save() {
                addDB();
                i=2;
                setContentView(R.layout.activity_main);
                mainlayout();
                solicitdialog.dismiss();
            }

            @Override
            public void Clear() {
                am();
                solicitdialog.dismiss();
            }

            @Override
            public void Delete() {
                fm();
                solicitdialog.dismiss();
            }
        });
    }//问询Dialog方法

}
