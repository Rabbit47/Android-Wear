/*
Copyright 2017 The Android Open Source Project

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */
package com.example.oven.timingnote;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import static com.example.oven.timingnote.NoteDB.ID;
import java.util.Date;
import java.util.HashSet;


/**
 * Basic section container.
 *
 * <p>TODO: Replace these with implementations to match your apps functionality.
 */
    public class SectionFragment extends Fragment {

    public enum Section {
        Home(R.string.menu_home,android.R.drawable.ic_menu_sort_by_size),
        Edit(R.string.menu_edit,android.R.drawable.ic_menu_edit),
        Delete(R.string.menu_delete,android.R.drawable.ic_menu_delete);

        final int titleRes;
        final int drawableRes;

        Section(final int titleRes, final int drawableRes) {
            this.titleRes = titleRes;
            this.drawableRes = drawableRes;
        }
    }//绑定菜单
    private NoteDB noteDB;
    private SQLiteDatabase dbReader;
    private SQLiteDatabase dbdelete;
    private SQLiteDatabase dbWriter;
    private Cursor cursor;
    private MyAdapter adapter;
    private LocalReceiver mReceiver;
    private int i=0;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        noteDB=new NoteDB(getActivity());
        dbWriter = noteDB.getWritableDatabase();
        dbReader=noteDB.getReadableDatabase();
        dbdelete=noteDB.getWritableDatabase();
        R_am();
        R_fm();
    }//后台初始化方法



    /**
     * Helper method to quickly create sections.
     *
     * @param section The {@link Section} to use.
     * @return A new SectionFragment with arguments set based on the provided Section.
     */
    public static SectionFragment getSection(final Section section) {
        final SectionFragment newSection = new SectionFragment();
        final Bundle arguments = new Bundle();
        arguments.putSerializable(EXTRA_SECTION, section);
        newSection.setArguments(arguments);
        return newSection;
    }

    public static final String EXTRA_SECTION = "com.example.oven.timingnote.EXTRA_SECTION";
    private ListView mListView;
    private Section mSection;
    private TextView mTitleView;
    private TextView mContentView;
    private TextView mEditText;
    private Solicitdialog solicitdialog;
    private Details_Dialog details_dialog;
    private String solicit;
    private HashSet<Integer> hashSet;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(
            LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        hashSet=new HashSet<Integer>();
        final View view = inflater.inflate(R.layout.fragment_section, container, false);
        mListView = (ListView) view.findViewById(R.id.list);
        mTitleView = (TextView) view.findViewById(R.id.title);
        mContentView= (TextView) view.findViewById(R.id.content);
        mEditText= (TextView) view.findViewById(R.id.datetime);
        solicitdialog= new Solicitdialog();
        details_dialog=new Details_Dialog();
        if (getArguments() != null) {
           mSection = (Section) getArguments().getSerializable(EXTRA_SECTION);
            if(mSection== Section.Home){
                mListView.setVisibility(View.VISIBLE);
                mTitleView.setVisibility(View.GONE);
                mContentView.setVisibility(View.GONE);
                mEditText.setVisibility(View.GONE);
                listbutton();
            }else if(mSection== Section.Edit){
                mListView.setVisibility(View.GONE);
                mTitleView.setVisibility(View.VISIBLE);
                mContentView.setVisibility(View.VISIBLE);
                mEditText.setVisibility(View.VISIBLE);
                mEditText.setText(getTime());
            }else if(mSection== Section.Delete){
                mListView.setVisibility(View.VISIBLE);
                mTitleView.setVisibility(View.GONE);
                mContentView.setVisibility(View.GONE);
                mEditText.setVisibility(View.GONE);
                listbuttondelete();


            }else {
                mSection= Section.Home;
                mListView.setVisibility(View.VISIBLE);
                mTitleView.setVisibility(View.GONE);
                mContentView.setVisibility(View.GONE);
                mEditText.setVisibility(View.GONE);
                listbutton();
            }
            mTitleView.setText(R.string.menu_title);
            mContentView.setText(R.string.menu_content);
        }

        return view;
    }//View初始化

    public void selectDB() {
        cursor = dbReader.query(NoteDB.TABLE_NAME, null, null, null, null,
                null, null);
        adapter = new MyAdapter(getActivity(), cursor);
        mListView.setAdapter(adapter);
    }//刷新列表
    public void deleteTable(SQLiteDatabase db){
        db.execSQL("delete from notes");
        db.execSQL("delete from sqlite_sequence where name='notes'");
        selectDB();
    }//清空数据库方法
    @Override
    public void onResume() {
        super.onResume();
        selectDB();
    }
    private void listbutton(){
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                cursor.moveToPosition(position);//获得列表的Position
                Bundle bundle = new Bundle();
                bundle.putString("position",position+"");
                bundle.putString("id",id+"");
                bundle.putLong(NoteDB.ID,
                        cursor.getInt(cursor.getColumnIndex(ID)));
                bundle.putString(NoteDB.CONTENT, cursor.getString(cursor
                        .getColumnIndex(NoteDB.CONTENT)));
                bundle.putString(NoteDB.TIME,
                        cursor.getString(cursor.getColumnIndex(NoteDB.TIME)));
                bundle.putString(NoteDB.TITLE,
                        cursor.getString(cursor.getColumnIndex(NoteDB.TITLE)));
                details(bundle);//浏览详情
            }
        });
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                return true;
            }
        });
    }//HOME listbutton
    public void listbuttondelete(){
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                solicit=getString(R.string.menu_delete);//获得通知文本
                cursor.moveToPosition(position);//获得列表的Position
                solicit(solicit);//进入通知

                return true;
            }
        });
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {//短按选中
                adapter.notifyDataSetChanged();//通知Item更新控件
                if(mListView.isItemChecked(position)){
                    hashSet.add(position);//hash获取item的position
                }else {
                    hashSet.remove(position);//hash释放item的position

                }

            }
        });

    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public String getTime() {//获取系统时间
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date curDate = new Date();
        String str = format.format(curDate);
        return str;
    }
    public void R_am(){
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction("Clear");
            mReceiver = new LocalReceiver();
            BroadCastManager.getInstance().registerReceiver(getActivity(),
                    mReceiver, filter);//AM注册广播接收者
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    class LocalReceiver extends BroadcastReceiver {


        @Override
        public void onReceive(Context context, Intent intent) {
            //收到广播后的处理
                String receive = intent.getAction();
                if(receive.equals("Clear")){//清空列表
                    loadData(receive);
                }
                String deletes=intent.getAction();
                if(deletes.equals("Deletes")){//多选删除，也可单选
                    DeleteDate(deletes);
                }


        }

        private void loadData(String receive) {
            deleteTable(dbdelete);//清除数据库

        }
        private void DeleteDate(String deletes){
            hashDelete();//hash过滤item的position
        }
    }
    @Override
    public void onDestroy() {
        BroadCastManager.getInstance().unregisterReceiver(getActivity(),mReceiver);
        super.onDestroy();
    }//关闭广播
    public void details(final Bundle bundle){

        details_dialog.setArguments(bundle);
        details_dialog.show(getFragmentManager(),null);
    }
    public void hashDelete(){
            if(hashSet.isEmpty()){
                Toast.makeText(getActivity(), R.string.No_selection_item, Toast.LENGTH_SHORT).show();
            }else {
                Object[] obj = hashSet.toArray();
                int temp[] = new int[obj.length];
                for (int i = 0; i < obj.length; i++) {
                    temp[i] = (int) obj[i];//将Object对象数组转为整型数组（强制向下转型）循环遍历Item的position逐条删除
                    cursor.moveToPosition(temp[i]);
                    int intemID=cursor.getInt(cursor.getColumnIndex("_id"));
                    dbWriter.delete("notes","_id=?",new String[]{intemID+""});
                }
                selectDB();
                hashSet.clear();
            }

    }
    public void R_fm(){
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction("Deletes");
            mReceiver = new LocalReceiver();
            BroadCastManager.getInstance().registerReceiver(getActivity(),
                   mReceiver, filter);//FM注册广播接收者
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public void solicit(final String solicit){

        Bundle bundle = new Bundle();
        bundle.putString("flag",solicit);
        solicitdialog.setArguments(bundle);
        solicitdialog.show(getFragmentManager(),null);
        solicitdialog.setOnShareClickListener(new Solicitdialog.OnShareClickListener() {
            @Override
            public void Save() {
                solicitdialog.dismiss();
            }

            @Override
            public void Clear() {

                solicitdialog.dismiss();
            }

            @Override
            public void Delete() {//删除方法

                int intemID=cursor.getInt(cursor.getColumnIndex("_id"));
                dbWriter.delete("notes","_id=?",new String[]{intemID+""});
                selectDB();
                solicitdialog.dismiss();
            }
        });
    }
}
