package com.example.oven.timingnote;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.text.Layout;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Details_Dialog extends DialogFragment implements View.OnClickListener{
    TextView details;
    ImageButton back;
    String title,content,datetime;
    private static Details_Dialog details_dialog;
    public static Details_Dialog newInstance(String Details) {
        Details_Dialog shareDialogFragment = new Details_Dialog();
        Bundle bundle = new Bundle();
        bundle.putString("title",Details);
        shareDialogFragment.setArguments(bundle);
        return shareDialogFragment;
    }

    public static Details_Dialog newInstance() {
        if (details_dialog == null) {
            Details_Dialog shareDialogFragment = new Details_Dialog();
        }
        return details_dialog;
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.details, container, false);
        details= (TextView) view.findViewById(R.id.details);
        back=view.findViewById(R.id.back1);
        details.setMovementMethod(ScrollingMovementMethod.getInstance());
        back.setOnClickListener(this);
        details.setText(Html.fromHtml("<b><tt>"+title+"</tt></b><br>"+content+"\r\n"+datetime));
        return view;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        title=bundle.getString(NoteDB.TITLE);
        content=bundle.getString(NoteDB.CONTENT);
        datetime= bundle.getString(NoteDB.TIME);
        setCancelable(true);

    }
    public Dialog onCreateDialog(Bundle savedInstanceState) {


        Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.details);//绑定布局
        dialog.setCanceledOnTouchOutside(true);

        // 设置宽度为屏宽、靠近屏幕底部。
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(wlp);

        return dialog;
    }
    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.back1:
               dismiss();

                break;

        }
    }

    @Override
    public void show(FragmentManager manager, String tag) {

        super.show(manager, tag);
    }


}
